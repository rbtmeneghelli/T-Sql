﻿using ConsoleApp1.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    class Program
    {
        private static Regra SendRequestObject()
        {
            //Objeto com propriedades apenas
            return new Regra();
        }

        private static Root SendRequestFullObject()
        {
            // Propriedades, 2 objetos e 1 lista
            return new Root();
        }

        private static List<Regra> SendRequestListObject()
        {
            //Somente lista
            return new Regra().getListaRegra();
        }

        private static RootObject SendRequestFullObjects()
        {
            //Propriedades, objetos, lista e objeto dentro da lista
            return new RootObject();
        }

        private static List<Cliente> SendRequestListComplex()
        {
            //Propriedades, objetos, lista e objeto dentro da lista
            return new Cliente().GetClientes();
        }

        static void Main(string[] args)
        {
            //Trabalhando com objeto
            var result = ReadPropertyValueService<RootObject, RootObject>.TradeSpecialCharactersToString(SendRequestFullObjects());

            //Trabalhando com lista simples
            //var result = ReadPropertyValueService<Regra, List<Regra>>.TradeSpecialCharactersToString(SendRequestListObject());

            //Trabalhando com lista complexa
            //var result = ReadPropertyValueService<Cliente, List<Cliente>>.TradeSpecialCharactersToString(SendRequestListComplex());

            Console.WriteLine("Resultado: " + JsonConvert.SerializeObject(result, Formatting.Indented));
        }
    }
}


