﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class ControleRequisicaoEndPointStressTest
    {
        public void Execute()
        {

            new Thread(new ThreadStart(CanExecute)).Start();
            new Thread(new ThreadStart(CanExecute)).Start();
            new Thread(new ThreadStart(CanExecute)).Start();
            new Thread(new ThreadStart(CanExecute)).Start();
           

        }

        private void CanExecute()
        {
            string authorizationToken = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEzNjYiLCJuYW1lIjoiRGllZ28gQ2FyZG9zbyIsImNucGoiOiI0MjQxMjcyNDAwMDE5MiIsImVtYWlsIjoiZC5zY2FyZG9zb0Bhdml2YXRlYy5jb20uYnIiLCJ0eXBlVXNlciI6IjYiLCJicm9rZXJJZCI6IiIsInRha2VySWQiOiIiLCJwcm9maWxlSWQiOiIxIiwidG9rZW4yRkEiOiJmYTBiZjdmM2FkMGJkNDUyYTk2MTY3MWUwNGEwZDFmNyIsIm5iZiI6MTY0NzUyNDA5NSwiZXhwIjoxNjQ3NTMxMjk1LCJpYXQiOjE2NDc1MjQwOTUsInRva2VuMkZBQXV0aGVudGljYXRlZCI6InRydWUifQ.kfl9EPGUBK5APSH4hew7kcjmPpkdQbHnJDJSez0kRTA";

            requestModelTest payload = new requestModelTest()
            {
                BrokerCnpj = "26039819000156",
                TakerCnpj = "33261694000170"
            };

            var client = new RestClient("http://localhost:7071/api/");

            var request = new RestRequest("Taker/Validate");

            request.RequestFormat = DataFormat.Json;
            request.AddJsonBody<requestModelTest>(payload);
            request.AddHeader("Authorization", authorizationToken);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "ActiveRoute=Home");

            var response = client.PostAsync(request).GetAwaiter().GetResult();

            Console.WriteLine(response.Content);
        }
    }
}
