﻿using ConsoleApp1.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public static class ReadPropertyValueService<TSource, TDestination> where TSource : class where TDestination : class
    {
        public static bool isNotList(object obj)
        {
            if (obj == null)
                return true;

            else if (obj is IList &&
                     obj.GetType().IsGenericType &&
                     obj.GetType().GetGenericTypeDefinition().IsAssignableFrom(typeof(List<>)))
            {
                return false;
            }

            return true;
        }

        public static bool isNotObject(object obj)
        {
            if (obj == null)
                return true;

            else if (obj.GetType() == typeof(TSource))
            {
                return false;
            }

            return true;
        }

        private static string EncodingString(string toEncode)
        {
            //28591
            byte[] bytes = Encoding.GetEncoding("UTF-8").GetBytes(toEncode);
            return Convert.ToBase64String(bytes);
        }

        private static string DecodingString(string toDecode)
        {
            byte[] bytes = Convert.FromBase64String(toDecode);
            return ASCIIEncoding.ASCII.GetString(bytes);
        }

        private static bool PropertyIsNotValid(object obj) => obj == null ? true : false;

        private static void getItemFromListToRead(IEnumerable elems)
        {
            foreach (var item in elems)
            {
                //Para cada item da lista, passo aqui...
                ReadPropertyFromObject(item);
            }
        }

        private static void getItemFromObjectToRead(object propValue) => ReadPropertyFromObject(propValue);

        private static void makeReplaceSpecialCharactersInResponse(PropertyInfo property, object obj)
        {
            List<string> charactersStringList = new List<string>() { "%", "'", "#", "“", "”", "`", "(", ")", "\"" };
            string data = string.Empty;

            if (property.PropertyType == typeof(string))
            {
                charactersStringList.ForEach(spCharacter =>
                {
                    data = property.GetValue(obj, null) as string;

                    if (string.IsNullOrWhiteSpace(data) == false)
                    {
                        string base64Decoded = EncodingString(spCharacter);
                        if (data.IndexOf(base64Decoded) != -1)
                        {
                            property.SetValue(obj, Regex.Replace(data.Trim(), base64Decoded, spCharacter, RegexOptions.IgnoreCase));
                        }
                    }
                });
            }
        }

        private static object ReadPropertyFromObject(object obj)
        {
            if (PropertyIsNotValid(obj))
                return obj;

            Type objType = obj.GetType();
            PropertyInfo[] properties = objType.GetProperties();

            foreach (PropertyInfo property in properties)
            {
                object propValue = property.GetValue(obj, null);
                var elems = propValue as IEnumerable;

                if (elems != null)
                {
                    getItemFromListToRead(elems);
                }
                if (property.PropertyType.Assembly == objType.Assembly)
                {
                    getItemFromObjectToRead(propValue);
                }
                else
                {
                    makeReplaceSpecialCharactersInResponse(property, obj);
                }
            }

            return obj;
        }

        public static TDestination TradeSpecialCharactersToString(object obj)
        {
            if (isNotObject(obj) && isNotList(obj))
                return obj as TDestination;

            if (isNotObject(obj) == false && isNotList(obj))
            {
                return ReadPropertyFromObject(obj) as TDestination;
            }

            else if (isNotList(obj) == false && isNotObject(obj))
            {
                List<TSource> result = new List<TSource>();

                foreach (object teste in obj as IList)
                {
                    var teste2 = ReadPropertyFromObject(teste) as object;
                    result.Add((TSource)teste2);
                }

                return result as TDestination;
            }

            return obj as TDestination;
        }
    }
}

//Fazer abstração de metodo e interface quando for implementar pro HUB