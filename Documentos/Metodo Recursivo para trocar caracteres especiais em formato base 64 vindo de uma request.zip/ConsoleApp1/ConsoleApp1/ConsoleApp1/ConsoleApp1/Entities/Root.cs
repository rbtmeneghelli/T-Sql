﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Entities
{
    public class Corretor
    {
        public int id_pessoa_corretor { get; set; }
        public int cd_tp_comissao { get; set; }
        public decimal pe_comissao { get; set; }
        public bool dv_corretor_lider { get; set; }
        public string testeCorretor { get; set; }

        public Corretor()
        {
            testeCorretor = "Corretor teste YA==234324YA==";
        }
    }

    public class ParcelaProposta
    {
        public int nr_parcela { get; set; }
        public decimal vl_adicional { get; set; }
        public DateTime dt_vencimento { get; set; }
        public decimal vl_iof { get; set; }
        public decimal vl_premio_tarifario { get; set; }
        public decimal vl_premio_total { get; set; }
        public decimal vl_custo { get; set; }
        public bool dv_situacao { get; set; }
        public string nomeParcelaProposta { get; set; }
        public decimal valorParcelaProposta { get; set; }
        public string descricaoParcelaProposta { get; set; }

        public ParcelaProposta()
        {
            nomeParcelaProposta = "Proposta JQ== KA== KQ== Jw== YA== Ig== KA== KQ== Iw== 4oCc 4oCd";
        }
    }

    public class Proposta
    {
        public int id_apolice { get; set; }
        public long id_endosso { get; set; }
        public string cd_apolice { get; set; }
        public DateTime dt_proposta { get; set; }
        public DateTime dt_validade { get; set; }
        public DateTime dt_inicio_vigencia { get; set; }
        public DateTime dt_fim_vigencia { get; set; }
        public string nm_status { get; set; }
        public int cd_status { get; set; }
        public int cd_proposta { get; set; }
        public int cd_produto { get; set; }
        public string nm_produto { get; set; }
        public int id_pessoa_corretor { get; set; }
        public string nm_pessoa_corretor { get; set; }
        public int id_pessoa_tomador { get; set; }
        public string nm_pessoa_tomador { get; set; }
        public string nr_cnpj_cpf_tomador { get; set; }
        public string cd_tp_pessoa_tomador { get; set; }
        public string nm_tp_pessoa_tomador { get; set; }
        public int id_endereco_tomador { get; set; }
        public int id_tp_endereco_tomador { get; set; }
        public string nm_tp_endereco_tomador { get; set; }
        public string nm_logradouro_tomador { get; set; }
        public int nr_rua_endereco_tomador { get; set; }
        public string nm_complemento_tomador { get; set; }
        public string nm_bairro_tomador { get; set; }
        public string nm_cidade_tomador { get; set; }
        public int cd_uf_tomador { get; set; }
        public string nm_uf_tomador { get; set; }
        public string nm_cep_tomador { get; set; }
        public string id_pessoa_segurado { get; set; }
        public string nm_pessoa_segurado { get; set; }
        public int cd_tp_pessoa_segurado { get; set; }
        public string nm_tp_pessoa_segurado { get; set; }
        public string nr_cnpj_cpf_segurado { get; set; }
        public int id_endereco_segurado { get; set; }
        public int id_tp_endereco_segurado { get; set; }
        public string nm_tp_endereco_segurado { get; set; }
        public string nm_logradouro_segurado { get; set; }
        public string nr_rua_endereco_segurado { get; set; }
        public string nm_complemento_segurado { get; set; }
        public string nm_bairro_segurado { get; set; }
        public string nm_cidade_segurado { get; set; }
        public int cd_uf_segurado { get; set; }
        public string nm_uf_segurado { get; set; }
        public string nm_cep_segurado { get; set; }
        public DateTime dados_cobranca_dt_vencimento_pparcela { get; set; }
        public int dados_cobranca_nr_dia_cobranca { get; set; }
        public int dados_cobranca_cd_forma_pagamento_pparcela { get; set; }
        public string dados_cobranca_nm_forma_pagamento_pparcela { get; set; }
        public int dados_cobranca_cd_forma_pagamento_demais_parc { get; set; }
        public string dados_cobranca_nm_forma_pagamento_demais_parcela { get; set; }
        public int dados_cobranca_id_produto_parc_premio { get; set; }
        public string dados_cobranca_nm_parcelamento { get; set; }
        public int dados_cobranca_id_periodo_pagamento { get; set; }
        public string dados_cobranca_nm_periodo { get; set; }
        public int dados_garantia_id_produto_cobertura { get; set; }
        public string dados_garantia_nm_cobertura { get; set; }
        public decimal dados_garantia_vl_premio_tarifario { get; set; }
        public decimal dados_garantia_vl_premio_net { get; set; }
        public string dados_garantia_Pe_comissao { get; set; }
        public decimal dados_garantia_vl_taxa_moeda { get; set; }
        public decimal dados_garantia_vl_adicional { get; set; }
        public decimal dados_garantia_Vl_comissao { get; set; }
        public decimal dados_garantia_vl_is { get; set; }
        public decimal dados_garantia_vl_taxa_risco { get; set; }
        public int dados_garantia_cd_moeda { get; set; }
        public decimal dados_garantia_vl_iof { get; set; }
        public string dados_garantia_pe_iof { get; set; }
        public string objeto_segurado_nm_objeto_segurado { get; set; }
        public int cd_usuario_inclusao { get; set; }
        public string nm_usuario_inclusao_login { get; set; }
        public bool dv_premio_calculo_manual { get; set; }
        public int cd_usuario_alteracao { get; set; }
        public string nm_usuario_alteracao_login { get; set; }
        public ParcelaProposta ParcelaProposta { get; set; }

        public Proposta()
        {
            ParcelaProposta = new ParcelaProposta();
        }
    }

    public class Regra
    {
        public int cd_regra { get; set; }
        public bool dv_regra { get; set; }
        public decimal vl_regra { get; set; }
        public string teste { get; set; }

        public Regra()
        {
            teste = "sgfsdjfhsdf34543534534543KA==sfssdfsdffdsKQ==";
        }

        public List<Regra> getListaRegra()
        {
            List<Regra> lista = new List<Regra>();

            for (int i = 0; i <= 10; i++)
            {
                lista.Add(new Regra()
                {
                    cd_regra = i,
                    dv_regra = true,
                    vl_regra = i * 2,
                    teste = "teste JQ== KA== KQ== Jw== YA== Ig== KA== KQ== Iw== 4oCc 4oCd"
                });
            }

            return lista;
        }
    }

    public class Root
    {
        public int cd_retorno { get; set; }
        public string nm_retorno { get; set; }
        public int nr_proposta { get; set; }
        public int id_apolice { get; set; }
        public Proposta Proposta { get; set; }
        public Corretor Corretores { get; set; }
        public List<Regra> Regras { get; set; }

        public Root()
        {
            Proposta = new Proposta();
            Corretores = new Corretor();
            Regras = new Regra().getListaRegra();
            nm_retorno = "teste JQ== KA== KQ== Jw== YA== Ig== KA== KQ== Iw== 4oCc 4oCd";
        }
    }

    public class RootObject
    {
        public int cd_retorno { get; set; }
        public string nm_retorno { get; set; }
        public Corretor Corretor1 { get; set; }
        public Corretor Corretor2 { get; set; }
        public List<RegraChild> Regras { get; set; }
        public List<RegraChild> Regras2 { get; set; }

        public RootObject()
        {
            Corretor1 = new Corretor();
            Corretor2 = new Corretor();
            Regras = new RegraChild().getListaRegra();
            Regras2 = new RegraChild().getListaRegra();
        }
    }

    public class RegraChild
    {
        public int cd_regra { get; set; }
        public bool dv_regra { get; set; }
        public decimal vl_regra { get; set; }
        public string teste { get; set; }
        public Corretor Corretor { get; set; }
        public Corretor Corretor2 { get; set; }

        public RegraChild()
        {
            teste = "sgfsdjfhsdf34543534534543KA==sfssdfsdffdsKQ==";
            Corretor = new Corretor();
            Corretor2 = new Corretor();
        }

        public List<RegraChild> getListaRegra()
        {
            List<RegraChild> lista = new List<RegraChild>();

            for (int i = 0; i <= 2; i++)
            {
                lista.Add(new RegraChild()
                {
                    cd_regra = i,
                    dv_regra = true,
                    vl_regra = i * 2,
                    teste = "teste JQ== KA== KQ== Jw== YA== Ig== KA== KQ== Iw== 4oCc 4oCd"
                });
            }

            return lista;
        }
    }

    public class Cliente
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
        public Endereco endereco { get; set; }
        public List<Venda> Vendas { get; set; }
        public int TotalVendas { get; set; }

        public List<Cliente> GetClientes()
        {
            List<Cliente> lista = new List<Cliente>();

            for (int i = 0; i <= 2; i++)
            {
                lista.Add(new Cliente()
                {
                    Id = i,
                    Descricao = $"Cliente JQ==XPTOJQ== {i}",
                    endereco = new Endereco(i),
                    Vendas = new Venda().GetVendas(),
                    TotalVendas = 3
                });

            }

            return lista;
        }
    }

    public class Endereco
    {
        public int id { get; set; }
        public string Cidade { get; set; }

        public Endereco(int id)
        {
            this.id = id;
            Cidade = "KA==São José dos CamposKQ==";
        }
    }

    public class Venda
    {
        public Guid IdVenda { get; set; }
        public string Descricao { get; set; }
        public List<Itens> itens { get; set; }

        public List<Venda> GetVendas()
        {
            List<Venda> lista = new List<Venda>();

            for (int i = 0; i <= 2; i++)
            {
                lista.Add(new Venda()
                {
                    IdVenda = Guid.NewGuid(),
                    Descricao = $"Venda XPTO 4oCc{IdVenda}4oCd",
                    itens = new List<Itens>()
                });

            }

            return lista;
        }
    }

    public class Itens
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
        public decimal valor { get; set; }
    }
}
